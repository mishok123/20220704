﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SBM_BLC1.Common;
using SBM_BLC1.DAL.Claim;
using SBM_BLC1.Entity.Common;
using CrystalDecisions.Enterprise;
using SBM_BLC1.Transaction;
using SBM_BLV1;
using SBM_BLC1.Common;
using SBM_BLC1.DAL.Common;

namespace SBM_WebUI.mp
{
    public partial class PreRequestDashBoard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session[Constants.SES_USER_CONFIG] != null)
            {
                if (!Page.IsPostBack)
                {
                    Util.InvalidateSession();
                    InitializeData();
                    ddlRequestType_SelectedIndexChanged(sender, e);
                    //This is for Page Permission
                    CheckPermission chkPer = new CheckPermission();
                    Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];
                    if (!chkPer.CheckPagePermission((Control)this.Page, oConfig, (int)Constants.PAGEINDEX_TRANS.SP_ISSUE_VIEW))
                    {
                        Response.Redirect(Constants.PAGE_ERROR, false);
                    }
                    //else if (oConfig.UserRole.Contains("HO"))
                    //{
                    //    Response.Redirect(Constants.PAGE_ERROR, false);
                    //}
                    //End Of Page Permission
                }
            }
            else
            {
                Response.Redirect(Constants.PAGE_LOGIN, false);
            }
        }

        protected void InitializeData()
        {
            DDListUtil.LoadDDLFromDB(ddlSpType, "SPTypeID", "TypeDesc", "SPMS_SPType", true);
            ddlRequestType.SelectedIndex = 0;
            ddlSpType.SelectedIndex = 1;

            
            DataTable dt1 = new DataTable();
            gvTransactionList.DataSource = dt1;
            gvTransactionList.DataBind();

            txtFromDate.Text = DateTime.Now.ToString(Constants.DATETIME_FORMAT);
            txtToDate.Text = DateTime.Now.ToString(Constants.DATETIME_FORMAT);

        }
        public void PopErrorMsgAction(string sType)
        {
            if (sType.Equals(Constants.BTN_APPROVE) || sType.Equals(Constants.BTN_REJECT))
            {
                Response.Redirect(Constants.PAGE_TRAN_APPROVAL + "?pType=" + Convert.ToString((int)Constants.PAGEINDEX_TRANS.SP_ISSUE_UPDATE).PadLeft(5, '0'), false);
            }
            else
            {
                // no action
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            Result oResult = null;
            PreRequestManagerDAL prm = new PreRequestManagerDAL();

            string dtFromDate = Util.GetDateTimeByString(txtFromDate.Text).ToString("dd-MMM-yyyy");
            string dtToDate = Util.GetDateTimeByString(txtToDate.Text).ToString("dd-MMM-yyyy");

            Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];
            if (oConfig.UserRole.Contains("HO"))
            {
                oResult = prm.Load_ViewPreReqDashboard_List(ddlSpType.SelectedValue.ToString(), ddlRequestType.Text, dtFromDate, dtToDate, ddlStatus.SelectedValue.ToString(), "");
            }
            else
            {
                oResult = prm.Load_ViewPreReqDashboard_List(ddlSpType.SelectedValue.ToString(), ddlRequestType.Text, dtFromDate, dtToDate, ddlStatus.SelectedValue.ToString(), oConfig.UserName);
            }
            if (oResult.Status)
            {
                gvTransactionList.DataSource = oResult.Return;
                gvTransactionList.DataBind();
            }
            else
            {
                DataTable dt1 = new DataTable();
                gvTransactionList.DataSource = dt1;
                gvTransactionList.DataBind();
            }
        }

        protected void ddlTransType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //btnDeleteAll.Visible = false;
            //if (ddlTransType.SelectedIndex > 0)
            //{
            //    if (ddlTransType.SelectedValue == "I")
            //    {
            //        btnDeleteAll.Visible = true;
            //    }
            //}
        }


        protected void gvTransactionList_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if ((e.Row.RowType == DataControlRowType.Header) || (e.Row.RowType == DataControlRowType.DataRow))
            {
                if ((e.Row.RowType == DataControlRowType.DataRow))
                {
                    for (int i = 0; i < e.Row.Cells.Count; i++)
                    {
                        e.Row.Cells[i].Wrap = true;

                        if (e.Row.Cells[i].Text == "Request")
                        {
                            e.Row.Cells[i].BackColor = System.Drawing.Color.Yellow;
                        }
                        else if (e.Row.Cells[i].Text == "WIP")
                        {
                            e.Row.Cells[i].BackColor = System.Drawing.Color.YellowGreen;
                        }
                        else if (e.Row.Cells[i].Text == "Approved")
                        {
                            e.Row.Cells[i].BackColor = System.Drawing.Color.Green;
                        }
                        e.Row.Cells[i].HorizontalAlign = HorizontalAlign.Center;
                    }
                }
                e.Row.Cells[0].Width = new Unit("100px");
                e.Row.Cells[1].Width = new Unit("100px");
                e.Row.Cells[2].Width = new Unit("120px");
                e.Row.Cells[3].Width = new Unit("50px");
                e.Row.Cells[4].Width = new Unit("100px");
                e.Row.Cells[5].Width = new Unit("120px");
                e.Row.Cells[6].Width = new Unit("100px");
                e.Row.Cells[7].Width = new Unit("100px");
                e.Row.Cells[8].Width = new Unit("75px");
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            PreRequestManagerDAL rdal = new PreRequestManagerDAL();
            Result oResult = new Result();
            Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];

            if (oConfig != null)
            {
                // Parameter
                string dtFromDate = Util.GetDateTimeByString(txtFromDate.Text).ToString("dd-MMM-yyyy");
                string dtToDate = Util.GetDateTimeByString(txtToDate.Text).ToString("dd-MMM-yyyy");

                if (oConfig.UserRole.Contains("HO"))
                {
                    oResult = rdal.Load_ViewPreReqDashboard_List(ddlSpType.SelectedValue.ToString(), ddlRequestType.Text, dtFromDate, dtToDate, ddlStatus.SelectedValue.ToString(), "");
                }
                else
                {
                    oResult = rdal.Load_ViewPreReqDashboard_List(ddlSpType.SelectedValue.ToString(), ddlRequestType.Text, dtFromDate, dtToDate, ddlStatus.SelectedValue.ToString(), oConfig.UserName);
                }

                if (oResult.Status)
                {
                    this.ExportToCSV((DataTable)oResult.Return, "");
                }
            }
        }
        private void ExportToCSV(DataTable table, string name)
        {
            string sValue = "";
            HttpContext context = HttpContext.Current;
            context.Response.Clear();
            foreach (DataColumn column in table.Columns)
            {
                context.Response.Write(column.ColumnName + ",");
            }
            context.Response.Write(Environment.NewLine);
            foreach (DataRow row in table.Rows)
            {
                for (int i = 0; i < table.Columns.Count; i++)
                {
                    if (row[i].GetType() == System.Type.GetType("System.DateTime"))
                    {
                        if (row[i] != DBNull.Value)
                        {
                            sValue = ((DateTime)row[i]).ToShortDateString();
                        }
                        else
                        {
                            sValue = "";
                        }
                        sValue = sValue.Replace(",", string.Empty);
                    }
                    else
                    {
                        sValue = row[i].ToString().Replace(",", string.Empty);
                        //sValue = sValue.Replace(";", string.Empty);
                    }

                    sValue = sValue.Replace("\n", string.Empty);
                    sValue = sValue.Replace("\r", string.Empty);
                    sValue = sValue.Replace("\t", string.Empty);
                    sValue = sValue.Replace(",", string.Empty);
                    context.Response.Write(sValue + ",");
                    sValue = "";
                }
                context.Response.Write(Environment.NewLine);
            }
            context.Response.ContentType = "text/csv";
            context.Response.AppendHeader("Content-Disposition", "attachment; filename=" + table.TableName.Trim() + ".csv");
            context.Response.End();
        }

        protected void ddlRequestType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlRequestType.SelectedIndex == 0)
            {
                ddlSpType.SelectedIndex = 0;
                ddlSpType.Enabled = false;
            }
            else
            {
                ddlSpType.SelectedIndex = 1;
                ddlSpType.Enabled = true;
            }
        }

    }
    }
