﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SBM_BLC1.Common;
using SBM_BLC1.DAL.Common;
using SBM_BLC1.Entity.Common;
using System.IO;
using SBM_BLC1.Transaction;

namespace SBM_WebUI.mp
{
    public partial class ExportOldDataDumps : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session[Constants.SES_USER_CONFIG] != null)
            {
                if (!Page.IsPostBack)
                {
                    Util.InvalidateSession(); 
                    InitializeData();
                    //This is for Page Permission
                    //CheckPermission chkPer = new CheckPermission();
                    //Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];
                    //if (!chkPer.CheckPagePermission((Control)this.Page, oConfig, (int)Constants.PAGEINDEX_REPORT.ISSUE_REGISTER))
                    //{
                    //    Response.Redirect(Constants.PAGE_ERROR, false);
                    //}
                    //End Of Page Permission
                }
            }
            else
            {
                Response.Redirect(Constants.PAGE_LOGIN, false);
            }
        }

        #region InitializeData
        private void InitializeData()
        {
            // Dropdown load SPType
            DDListUtil.LoadCheckBoxListFromDB(chkLSpType, "SPTypeID", "TypeDesc", "SPMS_SPType");

            for (int i = 0; i < chkLSpType.Items.Count; i++)
            {
                chkLSpType.Items[i].Selected = true;
            }


            txtFromDate.Text = DateTime.Now.ToString(Constants.DATETIME_FORMAT);
            txtToDate.Text = DateTime.Now.ToString(Constants.DATETIME_FORMAT);

            // load Report Type List
            rdlStatus.Items.Add(new ListItem("Issue Details", "ID"));
            rdlStatus.Items.Add(new ListItem("Customer Details", "CD"));
            rdlStatus.Items.Add(new ListItem("Nominee Details", "ND"));
            rdlStatus.Items.Add(new ListItem("Interest Payment Details", "IP"));
            rdlStatus.Items.Add(new ListItem("Encashment Payment Details", "EP"));
            
            rdlStatus.Items[0].Selected = true;

            Util.RBLChangeSetColor(rdlStatus);
            Util.RBLChangeColor(rdlStatus);
        }
        #endregion InitializeData


        protected void btnPrintPreview_Click(object sender, EventArgs e)
        {
            OldDataDAL oOldDataDAL = new OldDataDAL();
            Result oResult = new Result();
            Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];

            if (oConfig != null)
            {
                // Parameter
                string sCheckList = "";

                string sRptType = rdlStatus.SelectedValue;

                sCheckList = Util.GetCheckListIDList(chkLSpType);
                
                string dtFromDate = Util.GetDateTimeByString(txtFromDate.Text).ToString("dd-MMM-yyyy");
                string dtToDate = Util.GetDateTimeByString(txtToDate.Text).ToString("dd-MMM-yyyy");


                oResult = oOldDataDAL.ExportOldDataDumps(sRptType, sCheckList, dtFromDate, dtToDate);
                if (oResult.Status)
                {
                    this.ExportToCSV((DataTable)oResult.Return, "");
                }
            }
        }
        private void ExportToCSV(DataTable table, string name)
        {
            string sValue = "";
            HttpContext context = HttpContext.Current;
            context.Response.Clear();
            foreach (DataColumn column in table.Columns)
            {
                context.Response.Write(column.ColumnName + ",");
            }
            context.Response.Write(Environment.NewLine);
            foreach (DataRow row in table.Rows)
            {
                for (int i = 0; i < table.Columns.Count; i++)
                {
                    if (row[i].GetType() == System.Type.GetType("System.DateTime"))
                    {
                        if (row[i] != DBNull.Value)
                        {
                            sValue = ((DateTime)row[i]).ToShortDateString();
                        }
                        else
                        {
                            sValue = "";
                        }
                        sValue = sValue.Replace(",", string.Empty);
                    }
                    else
                    {
                        sValue = row[i].ToString().Replace(",", string.Empty);
                        //sValue = sValue.Replace(";", string.Empty);
                    }

                    sValue = sValue.Replace("\n", string.Empty);
                    sValue = sValue.Replace("\r", string.Empty);
                    sValue = sValue.Replace("\t", string.Empty);
                    sValue = sValue.Replace(",", string.Empty);
                    context.Response.Write(sValue + ",");
                    sValue = "";
                }
                context.Response.Write(Environment.NewLine);
            }
            context.Response.ContentType = "text/csv";
            context.Response.AppendHeader("Content-Disposition", "attachment; filename=" + table.TableName.Trim() + ".csv");
            context.Response.End();
        }
    }
}